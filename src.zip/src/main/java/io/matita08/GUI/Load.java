package io.matita08.GUI;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Scanner;

public class Load implements ActionListener {
   @Override
   public void actionPerformed(ActionEvent e) {
      JFileChooser fc = new JFileChooser();
      JFrame f = new JFrame("Open file");
      f.add(fc);
      fc.setFileFilter(new FileFilter() {//TODO Low priority: can be more clean?
         @Override
         public boolean accept(File f) {
            return f.getName().endsWith(".txt") || f.getName().endsWith(".bat") || f.getName().endsWith(".sim");
         }
         
         @Override
         public String getDescription() {
            return "Text file";
         }
      });
      fc.setVisible(true);
      fc.addActionListener(ne->{//TODO there *should* be a GUI.listeners package for those
         Display.instance.enableInputMethods(true);
         System.out.println(ne);
         f.setVisible(false);
         f.dispose();
         //if(ne.)
         try {
            System.out.println(fc.getSelectedFile().toString());
            System.out.println(new Scanner(new FileInputStream(fc.getSelectedFile())).nextLine());
         } catch (FileNotFoundException _) {}
      });
      try {
         UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
      } catch (ClassNotFoundException | InstantiationException | UnsupportedLookAndFeelException | IllegalAccessException ex) {
         //noinspection CallToPrintStackTrace
         ex.printStackTrace();
         throw new RuntimeException(ex);
      }
      f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
      f.pack();
      f.setVisible(true);
      Display.instance.enableInputMethods(false);
   }
}
